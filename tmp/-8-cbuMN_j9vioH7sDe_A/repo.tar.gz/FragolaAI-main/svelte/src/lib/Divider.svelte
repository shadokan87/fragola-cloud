<script lang="ts">
  export let margin = "1rem 0";
  </script>
<div class="divider" style:margin></div>

<style>
  .divider {
    border-top: 1px solid var(--vscode-input-border);
  }
</style>