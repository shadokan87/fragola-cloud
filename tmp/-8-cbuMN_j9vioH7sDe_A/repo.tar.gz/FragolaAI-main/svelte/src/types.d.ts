declare module 'crossoriginworker' {
    export default function getCrossOriginWorkerURL(url: string, options?: Record<string, any>): string;
}