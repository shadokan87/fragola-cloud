import type OpenAI from "openai";

export type chunkType = OpenAI.Chat.Completions.ChatCompletionChunk;
